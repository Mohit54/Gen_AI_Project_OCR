
<!-- PAGE 1 -->

PART 

HEALTH SCIENCES

# Chapter 02: General Anatomy and Physiology

## Learning Objectives

*After completing this chapter, you will be able to:*

- **LO 1** Explain the importance of anatomy and physiology to cosmetologists.
- **LO 2** Describe the structure and division of cells.
- **LO 3** List the four types of tissues in the body.
- **LO 4** Explain the basic functions of the organs and body systems.
- **LO 5** Outline the skeletal system's structures and functions.
- **LO 6** Describe the muscular system's components and supporting structures.
- **LO 7** Explain the nervous system's divisions and functions.
- **LO 8** List the functions of the circulatory system's components.
- **LO 9** Describe the lymphatic system's function.
- **LO 10** Explain the integumentary system's function.
- **LO 11** Outline the endocrine system's organs and their functions.

<!-- PAGE 2 -->

![img-0.jpeg](img-0.jpeg)

<!-- PAGE 3 -->

Everybody
is different,
and every body
is different.

“

—
Beverly Diehl

Writer
## Learning Objective 1

Explain the importance of anatomy
and physiology to cosmetologists.

## Why Study Anatomy and Physiology?

This chapter will guide you through all of the body systems that
need to work together to achieve healthy hair, nails, and skin. Start
with **anatomy** (also called gross anatomy), the study of human body
structures, how the body parts are organized, and the science of the
interconnected structures of organisms, or of their parts. Whereas,
**physiology** is the study of the functions or activities performed by the
body's structures.

Cosmetology services affect the skin; muscles; nerves; circulatory
system; and bones of the head, face, neck, shoulders, arms, hands, lower
legs, and feet. Hair, skin, and nail health is affected by the functions of
the body systems. Continue to educate yourself to stay informed on
health, wellness, and safety. Having a circle of experts as a resource is
also beneficial.

Cosmetologists should have a thorough understanding of anatomy and
physiology because:

- Scalp manipulations, facials, manicures, and pedicures are all
## Procedure
human anatomy.
- Recognizing healthy hair, skin, and nails is an important infection
control step, as is identifying conditions that require referral to a
## Remember
illness is never within a cosmetologist's scope of practice.
- Working with the bones of the face and skull contributes to
flattering haircuts, hairstyles, and makeup applications.

![img-1.jpeg](img-1.jpeg)

PART 02: HEALTH SCIENCES

<!-- PAGE 4 -->

In this chapter you will learn that:

- Cells are the basic structure of all living things.
- Tissues are made up of cells that are organized into layers or groups.
- Organs are groups of tissues that form complex structures and perform certain functions.
- Body systems contain organs that perform similar functions.
- Organisms are formed by groups of body systems; for example, the human body.
## Check In

1. Identify three cosmetology services that require a basic understanding of anatomy and physiology.

## Learning Objective 2

Describe the structure and division of cells.

## Cell Structure and Functions

Cells are the basic units of all living things: Bacteria, plants, and animals—including human beings—all have cells. A cell is made up of the protoplasm, in which nutrients, mineral salts, and water are present. Most cells also include a nucleus, cytoplasm, and cell membrane (Figure 2-1).

Cell structures and functions include the following:

- The nucleus is the specialized structure in the center of the cell. It controls the growth and reproduction of the cell; it also contains the cell's genetic material.
- Cytoplasm is the watery fluid that surrounds the nucleus. It provides a structure for the cell parts so that they can move freely within the cell membrane. Enzymes in the cytoplasm help digest and break down other molecules for food.
- The cell membrane is the thin layer of tissue that surrounds the cell. It protects the interior of the cell from its surroundings. It is semipermeable, meaning it allows certain substances to enter the cell.

Mitosis is the process of cell reproduction that occurs when the cell divides into two identical daughter cells. Cells require favorable conditions to grow and reproduce, including an adequate food supply, oxygen, water, suitable temperatures, and the ability to eliminate waste.

Cells convert nutrients to energy through a chemical process called metabolism. There are two types of metabolism:

1. Anabolism is the process of simple molecules combining to form a complex molecule. Anabolism requires energy.
2. Catabolism is the process of breaking complex molecules down into simple molecules. Catabolism releases energy.

![img-2.jpeg](img-2.jpeg)

Fig. 2-1

Basic structure of a cell.

Cytoplasm
# Chapter 02: GENERAL ANATOMY AND PHYSIOLOGY

<!-- PAGE 5 -->
## Focus On

### Why is Cell Structure Important?

*A client's response to different services and active ingredients in products will be influenced by the efficiency and speed of the cells' metabolism. Aging can influence the cells' metabolism, causing it to function less efficiently.*
## Check In

2. Describe the cell's basic structures.
3. What conditions are needed in order for cells to divide?

**LO 3** List the four types of tissues in the body.

## Tissues

A **tissue** is a group of similar cells that perform a specific function. There are four types of tissue in the body (Figure 2-2):

![img-3.jpeg](img-3.jpeg)

Fig. 2-2 Types of tissues.

![img-4.jpeg](img-4.jpeg)

**Epithelial tissue** provides a covering that protects the body and is found within many parts of the body such as skin, mucous membranes, digestive and respiratory organs, the lining of the mouth, the lining of the heart, and the glands.

![img-5.jpeg](img-5.jpeg)

**Nerve tissue** carries messages to and from the brain and controls and coordinates all bodily functions.

![img-6.jpeg](img-6.jpeg)

**Muscle tissue** contracts and moves various parts of the body.
## Check In

4. List the four types of tissue in the body.

PART 02: HEALTH SCIENCES

<!-- PAGE 6 -->

# **LO 4**

Explain the basic functions of the organs and body systems.
## Did You Know

*Systems, organs, tissues, and cells depend on each other to function properly. For example, if you become dehydrated, cells lose water causing tissue shrinkage, brain tissue fluid decreases, blood becomes thicker, and the body builds up wastes and acids causing headaches, muscle cramps, dizziness, rapid breathing, and confusion.*

## Organs and Body Systems

**Organs** are groups of specialized tissues that perform specific functions. Organs include the brain, heart, lungs, stomach and intestines, liver, kidneys, eyes, and skin. **Body systems**, also known as *systems*, are groups of organs acting together to perform one or more functions. **Table 2-1** outlines the body systems, indicating each system's functions and the major organs associated with that system.

Table 2-1

### Body Systems, Their Functions, and Major Organs

| BODY SYSTEMS | FUNCTION | MAJOR ORGANS AND RELATED STRUCTURES | WHY KNOW THIS? |
| --- | --- | --- | --- |
| **Circulatory** | Controls blood movement throughout the body | Heart, blood vessels | Massage affects the circulatory system, and good blood flow affects hair growth. Facial services and shaving (if permitted) benefit from awareness of arteries and veins for safety. |
| **Digestive** | Breaks food down into nutrients or waste for nutrition or excretion | Stomach, intestines, esophagus, salivary glands | Good nutrition allows optimum functioning of all body systems. |
| **Endocrine** | Controls hormone levels within the body that determine growth, development, reproduction, and health of entire body | Endocrine glands, hormones | Hormones produced by the endocrine system directly impact hair and skin. Some skin and hair conditions are a result of hormones. |

(Continued)
# Chapter 02: GENERAL ANATOMY AND PHYSIOLOGY

<!-- PAGE 7 -->

Table 2-1

## Body Systems, Their Functions, and Major Organs

| BODY SYSTEMS | FUNCTION | MAJOR ORGANS AND RELATED STRUCTURES | WHY KNOW THIS? |
| --- | --- | --- | --- |
| **Excretory** | Eliminates waste from the body, reducing the buildup of toxins | Kidneys, liver, skin, large intestine, lungs | The excretory system eliminates toxic substances that can affect other body system functions. |
| **Immune (lymphatic)** | Protects the body from disease by developing immunities and destroying pathogens and toxins | Lymph, lymph nodes, lymph vessels, spleen | The immune system protects the body from illness. Massage affects the lymphatic system. |
| **Integumentary** | Provides a protective covering and regulates body temperature | Skin, oil glands, sweat glands, hair, nails | The skin is the body's largest organ and its first line of defense against illness. Cosmetology services are directly affected by the health of the integumentary system. |
| **Muscular** | Covers, shapes, and holds the skeletal system in place; muscles contract to allow for movement of body structures | Muscles | Massage performed during cosmetology services affects the muscular system. A thorough understanding of the muscular system will also help prevent injuries during your career. |
| **Nervous** | Coordinates all other body systems, allowing them to work efficiently and react to the environment | Brain, spinal cord, nerves, eyes | To provide safe and effective facial and nail services, cosmetologists need an understanding of the nervous system. |
| **Reproductive** | Produces offspring and differentiates males from females as assigned at birth | Uterus, ovaries penis, testes | The reproductive system and hormonal changes that occur with different life stages affect hair growth, hair loss, and the skin. |

(Continued)

PART 02: HEALTH SCIENCES

<!-- PAGE 8 -->

Respiratory

![img-7.jpeg](img-7.jpeg)

Makes blood and oxygen available to body structures through respiration; eliminates carbon dioxide

Lungs, air passages

Adequate oxygenation of tissues allows optimum cell functioning; infection can be spread through respiration, affecting safety and cleanliness.

Skeletal

![img-8.jpeg](img-8.jpeg)

Forms the physical foundation of the body; composed of 206 bones connected by moveable and immovable joints

Bones, joints

Important for protecting your own body mechanics when working, as well as knowing bone structure when providing treatments, including makeup applications.
## Check In

5. What are organs?
6. Name the main body systems and their functions.
## Learning Objective 5

Outline the skeletal system's structures and functions.

# Skeletal System

The **skeletal system** forms the body's physical foundation and is composed of 206 bones that vary in size and shape. **Osteology** is the study of bones.

A **joint** is the connection between two or more bones. There are two types of joints:

1. Movable—joints in the elbows, knees, and hips; allow movement
2. Immovable—joints in the pelvis and skull; allow little or no movement (exceptions to this include during childbirth, when special hormones allow for flexibility of the pelvic joints)

Except for tooth enamel, bone is the hardest tissue in the body. It comprises connective tissue consisting of about one-third organic matter (cells and blood) and two-thirds minerals (calcium carbonate and calcium phosphate).
## Did You Know

*Joint pain is usually caused by inflammation of the tissue surrounding the joint, not by the joint itself. You have more than 230 movable and semi-movable joints in your body.*
# Chapter 02: GENERAL ANATOMY AND PHYSIOLOGY

<!-- PAGE 9 -->

The primary functions of the skeletal system are to:

- Give the body shape and support
- Protect various internal structures and organs
- Serve as attachments for muscles and act as levers to produce body movement
- Help produce white and red blood cells (one of bone marrow's functions)
- Store most of the body's calcium supply, as well as phosphorus, magnesium, and sodium
## Focus On

### Safety Considerations for the Skeletal System

An understanding of the skeletal system will help to protect your own body by using proper body mechanics when you work. It can also help determine placement of makeup during application and influence haircutting and hairstyling options according to your client's facial bone structure.

## Skull Bones

The **skull** is the head's skeleton and is divided into two parts:

1. **Cranium**—an oval, bony case consisting of eight bones that protect the brain
2. **Facial skeleton**—the framework of the face; composed of 14 bones

## Cranial Bones

Figure 2-3 shows the cranium's eight bones:

![img-9.jpeg](img-9.jpeg)

Fig. 2-3 Cranial and facial bones.

PART 02: HEALTH SCIENCES

<!-- PAGE 10 -->

## Facial Bones

The facial skeleton has 14 bones; **Figure 2-4** lists those most involved in cosmetology. The vomer, turbinate (2), and palatine (2) bones are the remaining bones in the facial skeleton and are not affected by cosmetology services.

![img-10.jpeg](img-10.jpeg)

**Fig. 2-4** Facial bones.

## Neck Bones

The main neck bones are the following (**Figure 2-5**):

![img-11.jpeg](img-11.jpeg)

**Fig. 2-5** Neck bones.
# Chapter 02: GENERAL ANATOMY AND PHYSIOLOGY

<!-- PAGE 11 -->

## Chest and Shoulder Bones

Figure 2-6 illustrates the bones of the chest and shoulder that are important in our industry when performing full-body treatments, such as body wraps, as well as for massage to learn as body reference landmarks and prevent injury to these areas:

![img-12.jpeg](img-12.jpeg)

Fig. 2-6 Shoulder bones.

## Arm and Hand Bones

Figure 2-7 lists the important bones of the arms and hands:

![img-13.jpeg](img-13.jpeg)

Fig. 2-7 Arm and hand bones.
## Did You Know

Repetitive motions, such as excessive wrist flexing or locking it in a bent position, can cause painful inflammation in the carpus area. Keep the wrist straight to prevent these injuries. Understanding anatomy and ergonomics can help prevent strains and injuries throughout your cosmetology career.

PART 02: HEALTH SCIENCES

<!-- PAGE 12 -->

## Leg, Ankle, and Foot Bones

Figure 2-8 shows three leg bones:

![img-14.jpeg](img-14.jpeg)

Fig. 2-8 Leg bones.

The ankle joint is composed of three bones: tibia, fibula, and talus. The ankle joint allows the foot's up-and-down movement (Figure 2-9). The foot has 26 bones subdivided into three categories: tarsals, metatarsals, phalanges.

![img-15.jpeg](img-15.jpeg)

Fig. 2-9 Ankle and foot bones.
# Chapter 02: GENERAL ANATOMY AND PHYSIOLOGY

<!-- PAGE 13 -->
## Did You Know

*A broken phalange may leave a finger or toe with some range of motion, but it will likely lose its dexterity, making it difficult to pick up very small objects.*
## Check In

7. List the skeletal system's primary functions.
8. Which facial bones are most involved in cosmetology services?
## Learning Objective 6

Describe the muscular system's components and supporting structures.

## Muscular System

The **muscular system** covers and holds the skeletal system in place and moves various body parts. Muscles are fibrous tissues that can stretch and contract according to body movements.

Some of the muscular system's functions are mobility, circulation, respiration, digestion, stability, and posture. **Myology** is the study of the structure, functions, and diseases of the muscular system.

There are more than 650 muscles in the body and three types of muscle.

1. **Cardiac muscle** is a type of striated muscle found only in the heart.
2. **Involuntary muscles** (nonstriated) are controlled by the autonomic nervous system and control body functions such as breathing and digestion.
3. **Voluntary muscles** (striated) are muscles that we control at will.
## Focus On

### *Safety Considerations for the Muscular System*

*Cosmetologists should know voluntary muscles' locations and what they control. These muscles can become fatigued from excessive work or injury. Clients can benefit from the massage techniques you incorporate into nail and skin care services. Improper massaging may also result in negative effects for the client, so it is important to understand the muscles' locations.*

PART 02: HEALTH SCIENCES

<!-- PAGE 14 -->

A muscle has three parts (Figure 2-10):

![img-16.jpeg](img-16.jpeg)

Fig. 2-10 Muscle origin and insertion.

Muscle tissue can be stimulated by:

- Massage
- Electric current therapy (see *Milady Standard Foundations Chapter 07, Electricity and Electrical Safety*, pp. 192–196)
- Infrared light
- Dry heat (heating lamps or heating caps)
- Moist heat (steamers or moderately warm steam towels)
- Nerve impulses (through the nervous system)
- Chemicals (certain acids and salts)

## Scalp and Neck Muscles

Figure 2-11 illustrates scalp and neck muscles:

![img-17.jpeg](img-17.jpeg)

Fig. 2-11 Scalp and neck muscles.
# Chapter 02: GENERAL ANATOMY AND PHYSIOLOGY

<!-- PAGE 15 -->

# Face, Nose, and Mouth Muscles

Figure 2-12 shows face, nose, and mouth muscles:

Corrugator

small muscle located between
the eyebrows below the frontalis;
draws the eyebrow down and
wrinkles the forehead vertically

Temporalis

located near the temple,
it opens and closes the jaw

Orbicularis oculi

ring muscle of the eye socket
that closes the eyelids and
assists in pumping tears

Levator labii superioris

muscle that surrounds and
elevates the upper lip and
dilates the nostrils, as when
expressing distaste

Masseter

originates at the lower
part of the zygomatic;
moves the mandible,
causing the mouth to close

Buccinator

muscle of the cheek between
the upper and lower jaw that
compresses the cheeks and
expels air between the lips

Triangularis

muscle at the corner of
the lip that extends over
the chin and pulls down
the corners of the mouth
when frowning

Depressor labii inferioris

muscle that surrounds and lowers
the lower lip and draws it to one side,
as when expressing sarcasm

Procerus

muscle that covers the bridge
of the nose, lowers the
eyebrows, and causes wrinkles
across the bridge of the nose

Levator palpebrae superioris

thin muscle that controls
the movement of the eyelid

Levator anguli oris

muscle that raises the angle
of the mouth and draws it inward

Zygomaticus minor

muscle that works with the
zygomaticus major to make
facial expressions

Zygomaticus major

muscle that extends from the
zygomatic bone to the angle of the
mouth; directs the lip outward and
upward when laughing or smiling

Risorius

muscle at the corner of the mouth
that draws it out and back,
as when grinning

Orbicularis oris

muscle that circles the mouth
and contracts, puckers,
and wrinkles the lips

Mentalis
## Tip
elevates the lower lip and raises
and wrinkles the skin of the chin

![img-18.jpeg](img-18.jpeg)

Fig. 2-12 Face, nose, and mouth muscles

PART 02: HEALTH SCIENCES

<!-- PAGE 16 -->
## Did You Know

About 40 to 50 percent of your body weight is in your muscles, with over 30 muscles in the face. These muscles control facial expressions and necessary motions such as **mastication**, which is the medical term for chewing. The primary mastication muscles are the temporalis and masseter.

## Shoulder and Arm Muscles
## Focus On

### Trapezius

covers the back of the neck as well as the upper and middle regions of the back; lifts and turns the head; raises the shoulders; controls swinging movements of the arm

### Deltoid

large, triangular muscle covering the shoulder joint that allows the arm to extend outward and to the side of the body

### Bicep

front of the upper arm; produces the contour of the front and inner side of the upper arm; lifts the forearm and flexes the elbow

### Supinator

forearm muscle that rotates the radius outward and the palm upward

Anterior or front

### Pronator

muscle that turns the hand inward so the palm faces downward

### Flexor

extensor muscle of the wrist involved in flexing or bending it

### Tricep

large muscle covering the entire back of the upper arm that extends the forearm and straightens the elbow

### Extensors

muscles that extend and straighten joints such as the wrist, hand, and fingers to form a straight line

Posterior or back

Fig. 2-13 Anterior and posterior shoulder and arm muscles.
## Did You Know

Specific terms can help describe a muscle's location:

- Anterior—in front
- Posterior—behind or at the rear
- Superior—above
- Inferior—below
# Chapter 02: GENERAL ANATOMY AND PHYSIOLOGY

<!-- PAGE 17 -->

## Hand Muscles

The hand is one of the most complex body parts, with many small muscles that overlap from joint to joint and provide the flexibility and strength to open and close the hand and fingers.

Figure 2-14 shows important muscles:

![img-19.jpeg](img-19.jpeg)

Fig. 2-14 Hand muscles.

## Lower Leg and Foot Muscles

These muscles are small and provide proper support and cushioning for the foot and leg (Figure 2-15). Knowledge of the lower leg and foot muscles is helpful during a pedicure.

![img-20.jpeg](img-20.jpeg)

Fig. 2-15 Lower leg muscles.

PART 02: HEALTH SCIENCES

<!-- PAGE 18 -->

Figure 2-16 illustrates foot muscles:

![img-21.jpeg](img-21.jpeg)

Fig. 2-16 Foot muscles (bottom).
## Caution

Massaging muscles properly can greatly benefit and relax a client. However, improper massaging may result in residual pain, nerve inflammation, and other negative effects. Direct massage pressure only from the insertion area to the origin.
## Check In

9. List the muscular system's basic functions.
10. Why do cosmetologists need knowledge of voluntary muscles?
11. What is the proper direction for massage?
12. What is the difference between striated and nonstriated muscles?

## Learning Objective 7

Explain the nervous system's divisions and functions.

# Nervous System

The nervous system is a well-organized body system composed of the brain, spinal cord, and nerves. It controls and coordinates all other body systems. Neurology is the study of the structure, function, and pathology of the nervous system.
# Chapter 02: GENERAL ANATOMY AND PHYSIOLOGY

<!-- PAGE 19 -->

## Nervous System Divisions

The nervous system has three main subdivisions which are the autonomic, central, and peripheral (Figure 2-17):

![img-22.jpeg](img-22.jpeg)

Fig. 2-17 Nervous system divisions.

![img-23.jpeg](img-23.jpeg)

Fig. 2-18 A neuron or nerve cell.

## The Brain and Spinal Cord

The **brain** is one of the body's most complex organs. It controls all the body's functions. The cranium protects the brain.

The **spinal cord** is the portion of the central nervous system that originates in the brain and extends down to the bottom of the spine. It is protected by the spinal column. There are 31 pairs of spinal nerves that extend from the spinal cord to the muscles, organs, and skin.

## Nerves

**Nerves** are whitish bundles of nerve fibers that transmit impulses. They originate in the brain and spinal cord and send their branches to all parts of the body (Figure 2-18).
## Did You Know

*Ever had your little finger go numb when leaning on your elbow? This is due to localized inflammation around the ulnar nerve, often referred to as the funny bone, that runs along the bottom of the elbow. When hitting your elbow, the ulnar nerve impulse causes that "funny" tingling sensation.*

PART 02: HEALTH SCIENCES

