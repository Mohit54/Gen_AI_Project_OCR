"""
Global configuration for Course Builder.
"""

from pathlib import Path
import os

# ==========================================================
# ROOT DIRECTORIES
# ==========================================================

ROOT_DIR = Path(__file__).resolve().parent.parent

INPUT_DIR = ROOT_DIR / "input"
OUTPUT_DIR = ROOT_DIR / "output"

INPUT_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

# ==========================================================
# MISTRAL
# ==========================================================

MISTRAL_API_KEY = "VLjZHYpZzYYV9FgPkDBr7GPlO8fOIi6B"

OCR_MODEL = "mistral-ocr-latest"

LLM_MODEL = "mistral-medium-latest"

# ==========================================================
# OUTPUT FILES
# ==========================================================

RAW_MD_NAME = "raw.md"

CLEAN_MD_NAME = "clean.md"

STRUCTURE_JSON_NAME = "structure.json"

CONCEPT_JSON_NAME = "concepts.json"

# ==========================================================
# PARSER
# ==========================================================

MAX_HEADER_LEVEL = 6

SAVE_RAW_JSON = True

SAVE_IMAGES = True

GENERATE_KEYWORDS = True

GENERATE_SUMMARY = True

GENERATE_CONCEPTS = True

GENERATE_LO = True

GENERATE_JSON = True