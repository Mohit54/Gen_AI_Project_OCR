from fastapi import FastAPI

from app.api.api import router


app = FastAPI(

    title="Milady  RAG",

    version="1.0.0"

)

app.include_router(router)


@app.get("/")
def home():

    return {

        "message": "Milady RAG API",

        "version": "1.0"

    }