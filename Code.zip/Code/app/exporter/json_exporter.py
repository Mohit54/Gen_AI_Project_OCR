import json
from pathlib import Path


class JSONExporter:

    @staticmethod
    def export_course_concepts(

        concepts,

        output_path

    ):

        data = [

            c.model_dump()

            for c in concepts

        ]

        Path(output_path).write_text(

            json.dumps(

                data,

                indent=4,

                ensure_ascii=False

            ),

            encoding="utf-8"

        )