"""
markdown_parser.py

Reads cleaned markdown and builds a document tree.

Book
 └── Chapter
      └── Learning Objective
            └── Concept
                  ├── SubConcept
                  ├── Sidebar
                  ├── Figure
                  └── Text
"""

import re

from app.parser.nodes import (
    BookNode,
    ChapterNode,
    LearningObjectiveNode,
    ConceptNode,
    SubConceptNode,
    SidebarNode,
    FigureNode,
    TableNode,
    TextNode,
)


SIDEBARS = [
    "Focus On",
    "Did You Know",
    "Check In",
    "Activity",
    "Procedure",
    "Review",
    "Remember",
    "Tip",
    "Caution",
]


class MarkdownParser:

    def __init__(self):

        self.book = BookNode(
            title="Book",
            level=0
        )

        self.stack = [self.book]

    # -----------------------------------------------------

    def current_node(self):

        return self.stack[-1]

    # -----------------------------------------------------

    def push(self, node):

        while len(self.stack) > node.level:

            self.stack.pop()

        self.stack[-1].add_child(node)

        self.stack.append(node)

    # -----------------------------------------------------

    def parse_header(self, line):

        match = re.match(r'^(#{1,6})\s+(.*)', line)

        if not match:
            return None

        hashes = match.group(1)
        title = match.group(2).strip()

        level = len(hashes)

        # -----------------------------

        if title.lower().startswith("chapter"):

            node = ChapterNode(
                title=title,
                level=level
            )

        elif title.lower().startswith("learning objective"):

            node = LearningObjectiveNode(
                title=title,
                level=level
            )

        elif title in SIDEBARS:

            node = SidebarNode(
                title=title,
                level=level
            )

        elif level == 2:

            node = ConceptNode(
                title=title,
                level=level
            )

        elif level >= 3:

            node = SubConceptNode(
                title=title,
                level=level
            )

        else:

            node = TextNode(
                title=title,
                level=level
            )

        self.push(node)

        return node

    # -----------------------------------------------------

    def parse_image(self, line):

        if "![" not in line:
            return False

        node = FigureNode(
            title=line.strip()
        )

        self.current_node().add_child(node)

        return True

    # -----------------------------------------------------

    def parse_table(self, line):

        if "|" not in line:
            return False

        node = TableNode(
            content=line
        )

        self.current_node().add_child(node)

        return True

    # -----------------------------------------------------

    def parse_text(self, line):

        if not line.strip():
            return

        node = TextNode(
            content=line
        )

        self.current_node().add_child(node)

    # -----------------------------------------------------

    def parse(self, markdown):

        lines = markdown.split("\n")

        for line in lines:

            line = line.rstrip()

            if not line:

                continue

            if self.parse_header(line):

                continue

            if self.parse_image(line):

                continue

            if self.parse_table(line):

                continue

            self.parse_text(line)

        return self.book

    # -----------------------------------------------------

    def print_tree(self, node=None, indent=0):

        if node is None:
            node = self.book

        print(
            " " * indent +
            f"{node.node_type} : {node.title}"
        )

        for child in node.children:

            self.print_tree(
                child,
                indent + 4
            )



