"""
nodes.py

Every markdown element becomes a Node.
Later ConceptBuilder will traverse this tree.
"""

from __future__ import annotations

from typing import List, Optional
from pydantic import BaseModel, Field


from pydantic import Field
# class Node(BaseModel):
#
#     id: str = ""
#
#     node_type: str
#
#     title: str = ""
#
#     content: str = ""
#
#     level: int = 0
#
#     page_start: int | None = None
#
#     page_end: int | None = None
#
#     line_start: int | None = None
#
#     line_end: int | None = None
#
#     source_markdown: str = ""
#
#     metadata: dict = {}
class Node(BaseModel):

    id: str = ""

    node_type: str

    title: str = ""

    content: str = ""

    level: int = 0

    page_start: int | None = None

    page_end: int | None = None

    line_start: int | None = None

    line_end: int | None = None

    source_markdown: str = ""



    metadata: dict = Field(default_factory=dict)
    children: List["Node"] = Field(default_factory=list)
    def add_child(self, child: "Node"):

        self.children.append(child)

    def is_header(self):

        return self.level > 0

    def __str__(self):

        return f"{self.node_type}: {self.title}"


class BookNode(Node):

    node_type: str = "BOOK"


class ChapterNode(Node):

    node_type: str = "CHAPTER"


class LearningObjectiveNode(Node):

    node_type: str = "LEARNING_OBJECTIVE"


class ConceptNode(Node):

    node_type: str = "CONCEPT"


class SubConceptNode(Node):

    node_type: str = "SUB_CONCEPT"


class SidebarNode(Node):

    node_type: str = "SIDEBAR"


class FigureNode(Node):

    node_type: str = "FIGURE"


class TableNode(Node):

    node_type: str = "TABLE"


class TextNode(Node):

    node_type: str = "TEXT"




Node.model_rebuild()