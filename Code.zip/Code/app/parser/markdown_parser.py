"""
markdown_parser.py

Parser V2

Converts cleaned markdown into a hierarchical document tree.

Book
 └── Chapter
      └── Learning Objective
            └── Concept
                  ├── SubConcept
                  ├── Sidebar
                  ├── Figure
                  ├── Table
                  └── Text
"""

import re

from app.parser.nodes import (
    BookNode,
    ChapterNode,
    LearningObjectiveNode,
    ConceptNode,
    SubConceptNode,
    SidebarNode,
    FigureNode,
    TableNode,
    TextNode,
)


# ---------------------------------------
# Sidebar Titles
# ---------------------------------------

# SIDEBARS = {
#
#     "focus on",
#     "did you know",
#     "check in",
#     "activity",
#     "procedure",
#     "review",
#     "remember",
#     "tip",
#     "caution",
# }
#
#
# # ---------------------------------------
# # Regular Expressions
# # ---------------------------------------
#
# PAGE_PATTERN = re.compile(
#     r'<!--\s*PAGE\s*(\d+)\s*-->',
#     re.IGNORECASE
# )
#
# HEADER_PATTERN = re.compile(
#     r'^(#{1,6})\s+(.*)'
# )
#
# CHAPTER_PATTERN = re.compile(
#     r'^chapter\s+\d+',
#     re.IGNORECASE
# )
#
# LO_PATTERN = re.compile(
#     r'^(learning\s*objective\s*\d+|lo\s*\d+)$',
#     re.IGNORECASE
# )
#
#
# class MarkdownParser:
#
#     # ==========================================
#     # Constructor
#     # ==========================================
#
#     def __init__(self):
#
#         self.book = BookNode(
#             title="Book",
#             level=0
#         )
#
#         self.stack = [self.book]
#
#         # -------------------------
#         # Parser State
#         # -------------------------
#
#         self.current_page = 1
#
#         self.current_chapter = None
#
#         self.current_learning_objective = None
#
#         self.current_concept = None
#
#     # ==========================================
#
#     def current_node(self):
#
#         return self.stack[-1]
#
#     # ==========================================
#
#     def push(self, node):
#
#         while len(self.stack) > node.level:
#
#             self.stack.pop()
#
#         self.stack[-1].add_child(node)
#
#         self.stack.append(node)

"""
markdown_parser.py

Parser V2

Converts cleaned markdown into a hierarchical document tree.

Book
 └── Chapter
      └── Learning Objective
            └── Concept
                  ├── SubConcept
                  ├── Sidebar
                  ├── Figure
                  ├── Table
                  └── Text
"""

import re

from app.parser.nodes import (
    BookNode,
    ChapterNode,
    LearningObjectiveNode,
    ConceptNode,
    SubConceptNode,
    SidebarNode,
    FigureNode,
    TableNode,
    TextNode,
)


# ---------------------------------------
# Sidebar Titles
# ---------------------------------------

SIDEBARS = {

    "focus on",
    "did you know",
    "check in",
    "activity",
    "procedure",
    "review",
    "remember",
    "tip",
    "caution",
}
#
#
# # ---------------------------------------
# # Regular Expressions
# # ---------------------------------------
#
PAGE_PATTERN = re.compile(
    r'<!--\s*PAGE\s*(\d+)\s*-->',
    re.IGNORECASE
)

HEADER_PATTERN = re.compile(
    r'^(#{1,6})\s+(.*)'
)

CHAPTER_PATTERN = re.compile(
    r'^chapter\s+\d+',
    re.IGNORECASE
)

LO_PATTERN = re.compile(
    r'^(learning\s*objective\s*\d+|lo\s*\d+)$',
    re.IGNORECASE
)


class MarkdownParser:

    # ==========================================
    # Constructor
    # ==========================================

    def __init__(self):

        self.book = BookNode(
            title="Book",
            level=0
        )

        self.stack = [self.book]

        # -------------------------
        # Parser State
        # -------------------------

        self.current_page = 1

        self.current_chapter = None

        self.current_learning_objective = None

        self.current_concept = None

    # ==========================================

    def current_node(self):

        return self.stack[-1]

    # ==========================================

    def push(self, node):

        while len(self.stack) > node.level:

            self.stack.pop()

        self.stack[-1].add_child(node)

        self.stack.append(node)

# =====================================================
# Figure Parser
# =====================================================

    def parse_image(self, lines, index):

        line = lines[index].strip()

        match = re.search(
            r'!\[(.*?)\]\((.*?)\)',
            line
        )

        if not match:
            return None

        image_name = match.group(2).strip()

        caption_lines = []

        j = index + 1

        while j < len(lines):

            text = lines[j].strip()

            if not text:
                j += 1
                continue

            if text.startswith("#"):
                break

            if text.startswith("!["):
                break

            if text.startswith("|"):
                break

            if PAGE_PATTERN.match(text):
                break

            caption_lines.append(text)

            j += 1

        caption = " ".join(caption_lines).strip()

        node = FigureNode(

            title=image_name,

            content=caption,

            page_start=self.current_page

        )

        self.current_node().add_child(node)

        #return j
        return max(j, index + 1)
    # =====================================================
    # Table Parser
    # =====================================================

    def parse_table(self, lines, index):

        line = lines[index]

        if "|" not in line:
            return None

        rows = []

        j = index

        while j < len(lines):

            text = lines[j]

            if "|" not in text:
                break

            rows.append(text.rstrip())

            j += 1

        node = TableNode(

            content="\n".join(rows),

            page_start=self.current_page

        )

        self.current_node().add_child(node)

        #return j

        return max(j, index + 1)


    # =====================================================
    # Text Parser
    # =====================================================

    def parse_text(self, lines, index):

        paragraphs = []

        j = index

        while j < len(lines):

            text = lines[j].rstrip()

            if not text:
                break

            if HEADER_PATTERN.match(text):
                break

            if text.startswith("!["):
                break

            if "|" in text:
                break

            if PAGE_PATTERN.match(text):
                break

            paragraphs.append(text)

            j += 1

        # if paragraphs:
        #
        #     node = TextNode(
        #
        #         content="\n".join(paragraphs),
        #
        #         page_start=self.current_page
        #
        #     )
        #
        #     self.current_node().add_child(node)
        #
        # return j
        if not paragraphs:
            return None

        node = TextNode(
            content="\n".join(paragraphs),
            page_start=self.current_page
        )

        self.current_node().add_child(node)

        return j

    def parse_header(self, line):


            match = HEADER_PATTERN.match(line)

            if not match:
                return False

            hashes = match.group(1)
            title = match.group(2).strip()

            level = len(hashes)

            title = re.sub(
                r"\*\*(.*?)\*\*",
                r"\1",
                title
            )

            title_lower = title.lower()

            if CHAPTER_PATTERN.match(title_lower):
                node = ChapterNode(
                    title=title,
                    level=1,
                    page_start=self.current_page
                )

                self.current_chapter = node

                self.push(node)

                return True

            if LO_PATTERN.match(title_lower) or title_lower.startswith("learning objective"):
                node = LearningObjectiveNode(
                    title=title,
                    level=2,
                    page_start=self.current_page
                )

                self.current_learning_objective = node

                self.push(node)

                return True

            if title_lower in SIDEBARS:
                node = SidebarNode(
                    title=title,
                    level=4,
                    page_start=self.current_page
                )

                self.push(node)

                return True

            if level == 2:
                node = ConceptNode(
                    title=title,
                    level=3,
                    page_start=self.current_page
                )

                self.current_concept = node

                self.push(node)

                return True

            if level >= 3:
                node = SubConceptNode(
                    title=title,
                    level=4,
                    page_start=self.current_page
                )

                self.push(node)

                return True

            return False
#         # =====================================================
#         # Page Marker Parser
#         # =====================================================
    def parse_page_marker(self, line):
        match = PAGE_PATTERN.match(line)
        if not match:
            return False

        self.current_page = int(match.group(1))
        return True
    #=====================================================
        # Main Parser
        # =====================================================

    def parse(self, markdown):

        lines = markdown.split("\n")

        i = 0

        while i < len(lines):

            line = lines[i].rstrip()

            if not line:
                i += 1
                continue

            if self.parse_page_marker(line):
                i += 1
                continue

            if self.parse_header(line):
                i += 1
                continue

            if line.startswith("!["):

                new_i = self.parse_image(lines, i)

                if new_i is not None:
                    i = new_i
                    continue

            if line.startswith("|"):

                new_i = self.parse_table(lines, i)

                if new_i is not None:
                    i = new_i
                    continue

            new_i = self.parse_text(lines, i)

            if new_i is not None:
                i = new_i
            else:
                i += 1

        return self.book

#     """
#     markdown_parser.py
#
#     Parser V2
#
#     Converts cleaned markdown into a hierarchical document tree.
#
#     Book
#      └── Chapter
#           └── Learning Objective
#                 └── Concept
#                       ├── SubConcept
#                       ├── Sidebar
#                       ├── Figure
#                       ├── Table
#                       └── Text
#     """

# import re
#
# from app.parser.nodes import (
#     BookNode,
#     ChapterNode,
#     LearningObjectiveNode,
#     ConceptNode,
#     SubConceptNode,
#     SidebarNode,
#     FigureNode,
#     TableNode,
#     TextNode,
# )
#
# # ---------------------------------------
# # Sidebar Titles
# # ---------------------------------------
#
# SIDEBARS = {
#
#     "focus on",
#     "did you know",
#     "check in",
#     "activity",
#     "procedure",
#     "review",
#     "remember",
#     "tip",
#     "caution",
# }
#
# # ---------------------------------------
# # Regular Expressions
# # ---------------------------------------
#
# PAGE_PATTERN = re.compile(
#     r'<!--\s*PAGE\s*(\d+)\s*-->',
#     re.IGNORECASE
# )
#
# HEADER_PATTERN = re.compile(
#     r'^(#{1,6})\s+(.*)'
# )
#
# CHAPTER_PATTERN = re.compile(
#     r'^chapter\s+\d+',
#     re.IGNORECASE
# )
#
# LO_PATTERN = re.compile(
#     r'^(learning\s*objective\s*\d+|lo\s*\d+)$',
#     re.IGNORECASE
# )
#
# class MarkdownParser:
#
#     # ==========================================
#     # Constructor
#     # ==========================================
#
#     def __init__(self):
#
#         self.book = BookNode(
#             title="Book",
#             level=0
#         )
#
#         self.stack = [self.book]
#
#         # -------------------------
#         # Parser State
#         # -------------------------
#
#         self.current_page = 1
#
#         self.current_chapter = None
#
#         self.current_learning_objective = None
#
#         self.current_concept = None
#
#     # ==========================================
#
#     def current_node(self):
#
#         return self.stack[-1]
#
#     # ==========================================
#
#     def push(self, node):
#
#         while len(self.stack) > node.level:
#             self.stack.pop()
#
#         self.stack[-1].add_child(node)
#
#         self.stack.append(node)
#
#     # =====================================================
#     # Figure Parser
#     # =====================================================
#
#     def parse_image(self, lines, index):
#
#         line = lines[index].strip()
#
#         match = re.search(
#             r'!\[(.*?)\]\((.*?)\)',
#             line
#         )
#
#         if not match:
#             return None
#
#         image_name = match.group(2).strip()
#
#         caption_lines = []
#
#         j = index + 1
#
#         while j < len(lines):
#
#             text = lines[j].strip()
#
#             if not text:
#                 j += 1
#                 continue
#
#             if text.startswith("#"):
#                 break
#
#             if text.startswith("!["):
#                 break
#
#             if text.startswith("|"):
#                 break
#
#             if PAGE_PATTERN.match(text):
#                 break
#
#             caption_lines.append(text)
#
#             j += 1
#
#         caption = " ".join(caption_lines).strip()
#
#         node = FigureNode(
#
#             title=image_name,
#
#             content=caption,
#
#             page_start=self.current_page
#
#         )
#
#         self.current_node().add_child(node)
#
#         return j
#
#     # =====================================================
#     # Table Parser
#     # =====================================================
#
#     def parse_table(self, lines, index):
#
#         line = lines[index]
#
#         if "|" not in line:
#             return None
#
#         rows = []
#
#         j = index
#
#         while j < len(lines):
#
#             text = lines[j]
#
#             if "|" not in text:
#                 break
#
#             rows.append(text.rstrip())
#
#             j += 1
#
#         node = TableNode(
#
#             content="\n".join(rows),
#
#             page_start=self.current_page
#
#         )
#
#         self.current_node().add_child(node)
#
#         return j
#
#     # =====================================================
#     # Text Parser
#     # =====================================================
#
#     def parse_text(self, lines, index):
#
#         paragraphs = []
#
#         j = index
#
#         while j < len(lines):
#
#             text = lines[j].rstrip()
#
#             if not text:
#                 break
#
#             if HEADER_PATTERN.match(text):
#                 break
#
#             if text.startswith("!["):
#                 break
#
#             if "|" in text:
#                 break
#
#             if PAGE_PATTERN.match(text):
#                 break
#
#             paragraphs.append(text)
#
#             j += 1
#
#         if paragraphs:
#             node = TextNode(
#
#                 content="\n".join(paragraphs),
#
#                 page_start=self.current_page
#
#             )
#
#             self.current_node().add_child(node)
#
#         return j
#
#     # =====================================================
#     # Header Parser
#     # =====================================================
#
#     def parse_header(self, line):
#
#         match = HEADER_PATTERN.match(line)
#
#         if not match:
#             return False
#
#         hashes = match.group(1)
#         title = match.group(2).strip()
#
#         level = len(hashes)
#
#         title = re.sub(
#             r"\*\*(.*?)\*\*",
#             r"\1",
#             title
#         )
#
#         title_lower = title.lower()
#
#         if CHAPTER_PATTERN.match(title_lower):
#             node = ChapterNode(
#                 title=title,
#                 level=1,
#                 page_start=self.current_page
#             )
#
#             self.current_chapter = node
#
#             self.push(node)
#
#             return True
#
#         if LO_PATTERN.match(title_lower) or title_lower.startswith("learning objective"):
#             node = LearningObjectiveNode(
#                 title=title,
#                 level=2,
#                 page_start=self.current_page
#             )
#
#             self.current_learning_objective = node
#
#             self.push(node)
#
#             return True
#
#         if title_lower in SIDEBARS:
#             node = SidebarNode(
#                 title=title,
#                 level=4,
#                 page_start=self.current_page
#             )
#
#             self.push(node)
#
#             return True
#
#         if level == 2:
#             node = ConceptNode(
#                 title=title,
#                 level=3,
#                 page_start=self.current_page
#             )
#
#             self.current_concept = node
#
#             self.push(node)
#
#             return True
#
#         if level >= 3:
#             node = SubConceptNode(
#                 title=title,
#                 level=4,
#                 page_start=self.current_page
#             )
#
#             self.push(node)
#
#             return True
#
#         return False
#
#         # =====================================================
#         # Page Marker Parser
#         # =====================================================
#     def parse_page_marker(self, line):
#         match = PAGE_PATTERN.match(line)
#         if not match:
#             return False
#
#         self.current_page = int(match.group(1))
#         return True
#     # =====================================================
#     # Main Parser
#     # =====================================================
#
#     def parse(self, markdown):
#
#         lines = markdown.split("\n")
#
#         i = 0
#
#         while i < len(lines):
#
#             line = lines[i].rstrip()
#
#             if not line:
#                 i += 1
#                 continue
#
#             if self.parse_page_marker(line):
#                 i += 1
#                 continue
#
#             if self.parse_header(line):
#                 i += 1
#                 continue
#
#             if line.startswith("!["):
#
#                 new_i = self.parse_image(lines, i)
#
#                 if new_i is not None:
#                     i = new_i
#                     continue
#
#             if line.startswith("|"):
#
#                 new_i = self.parse_table(lines, i)
#
#                 if new_i is not None:
#                     i = new_i
#                     continue
#
#             new_i = self.parse_text(lines, i)
#
#             if new_i is not None:
#                 i = new_i
#             else:
#                 i += 1
#
#         return self.book
#
#     # =====================================================
#     # Debug Tree
#     # =====================================================
#
#     def print_tree(self, node=None, indent=0):
#
#         if node is None:
#             node = self.book
#
#         print(
#             " " * indent +
#             f"{node.node_type} : {node.title}"
#         )
#
#         for child in node.children:
#             self.print_tree(
#                 child,
#                 indent + 4
#             )