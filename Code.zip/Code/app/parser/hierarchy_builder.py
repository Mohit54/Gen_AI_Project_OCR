"""
hierarchy_builder.py

Builds the educational hierarchy from parser nodes.

Parser Tree
    ↓
Book
    └── Lesson
            └── Learning Objective
                    └── Concept
"""
import re
from app.models import (
    Book,
    Lesson,
    LearningObjective,
    Concept,
    Sidebar,
    Figure,
    Table,
)


from app.parser.nodes import (
    BookNode,
    ChapterNode,
    LearningObjectiveNode,
    ConceptNode,
    SubConceptNode,
    SidebarNode,
    FigureNode,
    TableNode,
    TextNode,
)

class HierarchyBuilder:

    def __init__(self):

        self.book = None

        self.current_lesson = None
        self.current_lo = None
        self.current_concept = None

        self.lesson_map = {}
        self.lo_map = {}

        self.concept_counter = 1

    # =====================================================
    # PUBLIC
    # =====================================================
    def reset_current_context(self):

        self.current_lo = None
        self.current_concept = None
    def build(self, root: BookNode):

        self.book = Book(
            title=root.title or "Milady Book"
        )

        self.walk(root)

        return self.book

    # =====================================================
    # TREE WALK
    # =====================================================

    def walk(self, node):

        if isinstance(node, ChapterNode):
            self.handle_chapter(node)

        elif isinstance(node, LearningObjectiveNode):
            self.handle_learning_objective(node)

        elif isinstance(node, ConceptNode):
            self.handle_concept(node)

        elif isinstance(node, SubConceptNode):
            self.handle_subconcept(node)

        elif isinstance(node, SidebarNode):
            self.handle_sidebar(node)

        elif isinstance(node, FigureNode):
            self.handle_figure(node)

        elif isinstance(node, TableNode):
            self.handle_table(node)

        elif isinstance(node, TextNode):
            self.handle_text(node)

        for child in node.children:
            self.walk(child)

    # =====================================================
    # CHAPTER
    # =====================================================

    def handle_chapter(self, node):

        title = node.title.strip()

        # Ignore empty chapter titles
        if not title:
            return

        lesson = self.lesson_map.get(title)

        if lesson is None:
            lesson = Lesson(
                lesson_id=f"LESSON_{len(self.lesson_map) + 1}",
                title=title
            )

            self.lesson_map[title] = lesson
            self.book.add_lesson(lesson)

        self.current_lesson = lesson
        self.reset_current_context()
        self.current_lo = None
        self.current_concept = None

    # =====================================================
    # LEARNING OBJECTIVE
    # =====================================================

    def handle_learning_objective(self, node):

        if self.current_lesson is None:
            return

        title = node.title.strip()

        key = (
            self.current_lesson.lesson_id,
            title
        )

        lo = self.lo_map.get(key)

        if lo is None:
            lo = LearningObjective(
                id=f"LO_{len(self.current_lesson.learning_objectives) + 1}",
                text=title
            )

            self.current_lesson.add_learning_objective(lo)
            self.lo_map[key] = lo

        self.current_lo = lo

    # =====================================================
    # CONCEPT
    # =====================================================

    def handle_concept(self, node):

        if self.current_lesson is None:
            return

        concept = Concept(

            concept_id=f"C{self.concept_counter:04}",

            title=node.title,

            learning_objective=self.current_lo,

            heading_path=list(
                filter(
                    None,
                    [
                        self.current_lesson.title,
                        self.current_lo.text if self.current_lo else "",
                        node.title.strip()
                    ]
                )
            ),
            page_start=node.page_start,

            page_end=node.page_end
        )

        self.concept_counter += 1

        self.current_lesson.add_concept(concept)

        self.current_concept = concept

    # =====================================================
    # SUB CONCEPT
    # =====================================================

    def handle_subconcept(self, node):

        if self.current_concept is None:
            return

        self.current_concept.context += (
            f"\n\n### {node.title}\n\n"
        )

    # =====================================================
    # TEXT
    # =====================================================

    def handle_text(self, node):

        if self.current_concept is None:
            return

        text = node.content.strip()

        if not text:
            return

        # if self.current_concept.context:
        #     self.current_concept.context += "\n\n"
        #
        # self.current_concept.context += text
        if self.current_concept.context:
            self.current_concept.context += "\n\n"

        self.current_concept.context += text.strip()

    # =====================================================
    # SIDEBAR
    # =====================================================

    def handle_sidebar(self, node):

        if self.current_concept is None:
            return

        sidebar = Sidebar(
            sidebar_type=node.title.strip(),
            title=node.title.strip(),
            content=node.content.strip()
        )

        self.current_concept.sidebars.append(sidebar)

    # =====================================================
    # FIGURE
    # =====================================================

    def handle_figure(self, node):

        if self.current_concept is None:
            return

        match = re.search(r'img-[^)]+', node.title)

        #image_name = match.group(0) if match else node.title.strip()
        match = re.search(r'img-[\w\-]+\.(jpeg|jpg|png)', node.title, re.IGNORECASE)

        image_name = (
            match.group(0)
            if match
            else node.title.strip()
        )
        print(Figure.model_json_schema())
        figure = Figure(
            image=image_name,
            #caption="",
            caption=node.content.strip(),
            page=node.page_start
        )

        self.current_concept.figures.append(figure)

    # =====================================================
    # TABLE
    # =====================================================

    def handle_table(self, node):

        if self.current_concept is None:
            return

        table = Table(
            markdown=node.content.strip(),
            caption=""
        )

        self.current_concept.tables.append(table)

        # def print_summary(self):
        #
        #     print("\nBOOK SUMMARY")
        #     print("=" * 40)
        #
        #     for lesson in self.book.lessons:
        #
        #         print(f"\nLesson : {lesson.title}")
        #
        #         print(f"LOs : {len(lesson.learning_objectives)}")
        #
        #         print(f"Concepts : {len(lesson.concepts)}")
        #
        #         for concept in lesson.concepts:
        #             print(f"   - {concept.title}")

    def print_summary(self):

        print("\n" + "=" * 60)
        print("BOOK SUMMARY")
        print("=" * 60)

        print(f"Lessons : {len(self.book.lessons)}")

        total_los = 0
        total_concepts = 0
        total_sidebars = 0
        total_figures = 0
        total_tables = 0

        for lesson in self.book.lessons:

            total_los += len(lesson.learning_objectives)
            total_concepts += len(lesson.concepts)

            print(f"\nLesson : {lesson.title}")
            print(f"   LOs : {len(lesson.learning_objectives)}")
            print(f"   Concepts : {len(lesson.concepts)}")

            for concept in lesson.concepts:
                total_sidebars += len(concept.sidebars)
                total_figures += len(concept.figures)
                total_tables += len(concept.tables)

        print("\nTotals")
        print("-" * 40)
        print(f"Lessons    : {len(self.book.lessons)}")
        print(f"LOs        : {total_los}")
        print(f"Concepts   : {total_concepts}")
        print(f"Sidebars   : {total_sidebars}")
        print(f"Figures    : {total_figures}")
        print(f"Tables     : {total_tables}")