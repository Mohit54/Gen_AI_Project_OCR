"""
markdown_cleaner.py

Normalizes OCR markdown before parsing.

Responsibilities

✓ Remove duplicate spaces
✓ Normalize headings
✓ Remove page numbers
✓ Remove running headers
✓ Normalize sidebar headings
✓ Normalize Learning Objectives
"""

import re
from pathlib import Path


class MarkdownCleaner:

    def __init__(self):

        pass

    # --------------------------------------------------
    # Normalize Line Endings
    # --------------------------------------------------

    def normalize_newlines(self, text):

        return text.replace("\r\n", "\n")

    # --------------------------------------------------
    # Remove Extra Blank Lines
    # --------------------------------------------------

    def remove_extra_blank_lines(self, text):

        return re.sub(
            r"\n{3,}",
            "\n\n",
            text
        )

    # --------------------------------------------------
    # Remove Standalone Page Numbers
    # --------------------------------------------------

    def remove_page_numbers(self, text):

        cleaned = []

        for line in text.split("\n"):

            if re.fullmatch(r"\d+", line.strip()):
                continue

            cleaned.append(line)

        return "\n".join(cleaned)

    # --------------------------------------------------
    # Normalize Learning Objectives
    # --------------------------------------------------

    def normalize_learning_objectives(self, text):

        text = re.sub(

            r"^#*\s*LO\s*(\d+)",

            r"## Learning Objective \1",

            text,

            flags=re.MULTILINE
        )

        return text

    # --------------------------------------------------
    # Normalize Sidebar Headings
    # --------------------------------------------------

    def normalize_sidebars(self, text):

        sidebar_map = {

            r"did you know": "## Did You Know",

            r"focus on": "## Focus On",

            r"check in": "## Check In",

            r"caution": "## Caution",

            r"activity": "## Activity",

            r"procedure": "## Procedure",

            r"tip": "## Tip",

            r"remember": "## Remember",

            r"review": "## Review"

        }

        for pattern, replacement in sidebar_map.items():

            text = re.sub(

                rf"^#*\s*.*{pattern}.*$",

                replacement,

                text,

                flags=re.IGNORECASE | re.MULTILINE

            )

        return text

    # --------------------------------------------------
    # Normalize Chapter Heading
    # --------------------------------------------------

    def normalize_chapters(self, text):

        text = re.sub(

            r"^#*\s*chapter\s+(\d+)",

            r"# Chapter \1",

            text,

            flags=re.IGNORECASE | re.MULTILINE

        )

        return text

    # --------------------------------------------------
    # Remove Duplicate Spaces
    # --------------------------------------------------
    # --------------------------------------------------
    # Merge Chapter Title
    # --------------------------------------------------

    # --------------------------------------------------
    # Merge Chapter Title
    # --------------------------------------------------

    def merge_chapter_titles(self, text):

        lines = text.split("\n")

        merged = []

        i = 0

        while i < len(lines):

            line = lines[i].strip()

            # Match:
            # # Chapter 02
            # # Chapter 02:
            match = re.match(
                r"^#\s*Chapter\s+\d+\s*:?\s*$",
                line,
                flags=re.IGNORECASE,
            )

            if match:

                j = i + 1

                # Skip blank lines
                while j < len(lines) and not lines[j].strip():
                    j += 1

                if j < len(lines):

                    next_line = lines[j].strip()

                    # Next heading becomes chapter title
                    if next_line.startswith("#"):
                        heading = next_line.lstrip("#").strip()

                        merged.append(
                            f"{line.rstrip(':').strip()}: {heading}"
                        )

                        i = j + 1
                        continue

            merged.append(lines[i])

            i += 1

        return "\n".join(merged)
    def normalize_spaces(self, text):

        return re.sub(
            r"[ \t]+",
            " ",
            text
        )

    # --------------------------------------------------
    # Clean Pipeline
    # --------------------------------------------------

    def clean(self, markdown):

        markdown = self.normalize_newlines(markdown)

        markdown = self.remove_page_numbers(markdown)

        markdown = self.normalize_spaces(markdown)

        markdown = self.normalize_learning_objectives(markdown)

        markdown = self.normalize_sidebars(markdown)

        markdown = self.normalize_chapters(markdown)

        markdown = self.remove_extra_blank_lines(markdown)
        markdown = self.normalize_chapters(markdown)

        markdown = self.merge_chapter_titles(markdown)

        markdown = self.remove_extra_blank_lines(markdown)
        #
        # markdown = self.normalize_bold_headings()
        #
        # markdown = self.normalize_images()
        #
        # markdown = self.normalize_figures()
        #
        # markdown = self.normalize_tables()
        #
        # markdown = self.remove_page_markers()
        #
        # markdown = self.merge_chapter_title()
        #
        # markdown = self.remove_duplicate_chapters()

        return markdown

    # --------------------------------------------------

    def clean_file(self, input_file, output_file):

        markdown = Path(input_file).read_text(
            encoding="utf8"
        )

        cleaned = self.clean(markdown)

        Path(output_file).write_text(

            cleaned,

            encoding="utf8"

        )

        print(f"Saved {output_file}")