from app.builder.keyword_extractor import KeywordExtractor


class KeywordBuilder:

    def build(self, concepts):

        for concept in concepts:

            concept.keywords = KeywordExtractor.extract(
                concept.content
            )

        return concepts