import re


class KeywordExtractor:

    @staticmethod
    def extract(text: str):

        if not text:
            return []

        keywords = re.findall(
            r"\*\*([^*]+)\*\*",
            text
        )

        cleaned = []

        seen = set()

        for word in keywords:

            word = word.strip()

            if not word:
                continue

            if word.lower() in seen:
                continue

            seen.add(word.lower())

            cleaned.append(word)

        return cleaned