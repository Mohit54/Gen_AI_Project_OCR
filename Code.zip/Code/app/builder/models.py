# from pydantic import BaseModel, Field
#
#
# class CourseConcept(BaseModel):
#
#     # -----------------------------
#     # IDs
#     # -----------------------------
#
#     concept_id: str
#
#     lesson_id: str
#
#     lesson_title: str
#
#     # -----------------------------
#     # Learning
#     # -----------------------------
#
#     learning_objective: str = ""
#
#     # -----------------------------
#     # Heading
#     # -----------------------------
#
#     heading: str
#
#     heading_path: list[str] = Field(default_factory=list)
#
#     # -----------------------------
#     # Generated Context
#     # -----------------------------
#
#     context: str = ""
#
#     # -----------------------------
#     # Original Content
#     # -----------------------------
#
#     content: str = ""
#
#     # -----------------------------
#     # Generated Later
#     # -----------------------------
#
#     keywords: list[str] = Field(default_factory=list)
#
#     summary: str = ""
#
#     bloom_level: str = ""
#
#     difficulty: str = ""
#
#     # -----------------------------
#     # Educational Assets
#     # -----------------------------
#
#     figures: list = Field(default_factory=list)
#
#     tables: list = Field(default_factory=list)
#
#     sidebars: list = Field(default_factory=list)
#
#     glossary: list = Field(default_factory=list)
#
#     activities: list = Field(default_factory=list)
#
#     check_ins: list = Field(default_factory=list)
#
#     mcqs: list = Field(default_factory=list)
#
#     # -----------------------------
#
#     page_start: int | None = None
#
#     page_end: int | None = None
#
#     markdown: str = ""      # Original markdown with **bold**



from typing import Any

from pydantic import BaseModel, Field


class CourseConcept(BaseModel):

    # ==================================================
    # IDs
    # ==================================================

    concept_id: str

    lesson_id: str

    lesson_title: str

    # ==================================================
    # Learning
    # ==================================================

    learning_objective: str = ""

    bloom_level: str = ""

    difficulty: str = ""

    # ==================================================
    # Heading
    # ==================================================

    heading: str

    heading_path: list[str] = Field(default_factory=list)

    # ==================================================
    # Context
    # ==================================================

    context: str = ""

    content: str = ""

    markdown: str = ""

    summary: str = ""

    # ==================================================
    # Keywords
    # ==================================================

    keywords: list[str] = Field(default_factory=list)

    glossary: list[str] = Field(default_factory=list)

    # ==================================================
    # Educational Components
    # ==================================================

    definitions: list[str] = Field(default_factory=list)
    
    examples: list[str] = Field(default_factory=list)

    procedures: list[str] = Field(default_factory=list)

    important_points: list[str] = Field(default_factory=list)

    notes: list[str] = Field(default_factory=list)

    warnings: list[str] = Field(default_factory=list)

    activities: list[Any] = Field(default_factory=list)

    check_ins: list[Any] = Field(default_factory=list)

    mcqs: list[Any] = Field(default_factory=list)

    # ==================================================
    # Visual Components
    # ==================================================

    figures: list[Any] = Field(default_factory=list)

    tables: list[Any] = Field(default_factory=list)

    sidebars: list[Any] = Field(default_factory=list)

    # ==================================================
    # Metadata
    # ==================================================

    metadata: dict[str, Any] = Field(default_factory=dict)

    # ==================================================
    # Page Information
    # ==================================================

    page_start: int | None = None

    page_end: int | None = None