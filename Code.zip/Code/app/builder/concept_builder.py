# from app.builder.models import CourseConcept
#
#
# class ConceptBuilder:
#
#     def __init__(self):
#
#         self.output = []
#
#     # ---------------------------------------
#
#     def build(self, book):
#
#         for lesson in book.lessons:
#
#             for concept in lesson.concepts:
#
#                 self.output.append(
#
#                     self.build_concept(
#
#                         lesson,
#
#                         concept
#
#                     )
#
#                 )
#
#         return self.output
#
#     # ---------------------------------------
#
#     def build_concept(
#
#         self,
#
#         lesson,
#
#         concept
#
#     ):
#
#         context = self.generate_context(
#
#             lesson,
#
#             concept
#
#         )
#         print(concept.context[:500])
#         return CourseConcept(
#
#         concept_id=concept.concept_id,
#
#         lesson_id=lesson.lesson_id,
#
#         lesson_title=lesson.title,
#
#         learning_objective=(
#             concept.learning_objective.text
#             if concept.learning_objective
#             else ""
#         ),
#
#         heading=concept.title,
#
#         heading_path=concept.heading_path,
#
#         context=context,
#
#         content=concept.context,
#
#         markdown=concept.context,      # <-- ADD THIS
#
#         figures=concept.figures,
#
#         tables=concept.tables,
#
#         sidebars=concept.sidebars,
#
#         page_start=concept.page_start,
#
#         page_end=concept.page_end
#     )
#     # ---------------------------------------
#
#     def generate_context(
#
#         self,
#
#         lesson,
#
#         concept
#
#     ):
#
#         parts = [
#
#             lesson.title
#
#         ]
#
#         if concept.learning_objective:
#
#             parts.append(
#
#                 concept.learning_objective.text
#
#             )
#
#         if concept.heading_path:
#
#             parts.append(
#
#                 " > ".join(
#
#                     concept.heading_path
#
#                 )
#
#             )
#
#         return "\n".join(parts)


from app.builder.models import CourseConcept
from app.nlp.definition_extractor import DefinitionExtractor

class ConceptBuilder:

    def __init__(self):

        self.output = []

    # --------------------------------------------------

    def build(self, book):

        self.output = []

        for lesson in book.lessons:

            for concept in lesson.concepts:

                self.output.append(

                    self.build_concept(
                        lesson,
                        concept
                    )
                )

        return self.output

    # --------------------------------------------------

    def build_concept(
        self,
        lesson,
        concept
    ):

        metadata = self.generate_metadata(
            lesson,
            concept
        )

        context = self.generate_context(
            lesson,
            concept
        )
        definitions = DefinitionExtractor.extract(
            concept.context
        )
        return CourseConcept(

            # --------------------------
            # IDs
            # --------------------------

            concept_id=concept.concept_id,

            lesson_id=lesson.lesson_id,

            # --------------------------
            # Lesson
            # --------------------------

            lesson_title=lesson.title,

            learning_objective=(
                concept.learning_objective.text
                if concept.learning_objective
                else ""
            ),

            heading=concept.title,

            heading_path=concept.heading_path,

            # --------------------------
            # Content
            # --------------------------

            context=context,

            content=concept.context,

            markdown=concept.context,

            summary="",

            metadata=metadata,

            # --------------------------
            # Assets
            # --------------------------

            figures=concept.figures,

            tables=concept.tables,

            sidebars=concept.sidebars,

            # --------------------------
            # NLP (future)
            # --------------------------

            definitions=definitions,

            examples=[],

            procedures=[],

            important_points=[],

            activities=[],

            # --------------------------
            # Pages
            # --------------------------

            page_start=concept.page_start,

            page_end=concept.page_end
        )

    # --------------------------------------------------

    def generate_context(
        self,
        lesson,
        concept
    ):

        parts = [

            f"Lesson: {lesson.title}"

        ]

        if concept.learning_objective:

            parts.append(

                f"Learning Objective: {concept.learning_objective.text}"

            )

        if concept.heading_path:

            parts.append(

                "Heading Path: "

                + " > ".join(concept.heading_path)

            )

        return "\n".join(parts)

    # --------------------------------------------------

    def generate_metadata(
        self,
        lesson,
        concept
    ):

        return {

            "lesson": lesson.title,

            "lesson_id": lesson.lesson_id,

            "concept_id": concept.concept_id,

            "heading": concept.title,

            "heading_path": concept.heading_path,

            "learning_objective": (

                concept.learning_objective.text

                if concept.learning_objective

                else ""

            ),

            "page_start": concept.page_start,

            "page_end": concept.page_end,

            "figure_count": len(concept.figures),

            "table_count": len(concept.tables),

            "sidebar_count": len(concept.sidebars),

            "word_count": len(

                concept.context.split()

            ),

            "character_count": len(

                concept.context

            )
        }