# from fastapi import APIRouter
#
# router = APIRouter(
#     prefix="/api/v1",
#     tags=["Educational RAG"]
# )
#
#
# @router.get("/health")
# def health():
#
#     return {
#         "status": "healthy",
#         "service": "Milady RAG API"
#     }


from fastapi import APIRouter, HTTPException

from app.api.schemas import (
    AskRequest,
    AskResponse,
    Source
)

from app.rag.rag_service import RAGService


router = APIRouter(
    prefix="/api/v1",
    tags=["Educational RAG"]
)

# ---------------------------------------
# Initialize RAG
# ---------------------------------------

API_KEY = "YOUR_OPENAI_API_KEY"

rag = RAGService(API_KEY)

# ---------------------------------------
# Health
# ---------------------------------------

@router.get("/health")
def health():

    return {
        "status": "healthy"
    }


# ---------------------------------------
# Ask
# ---------------------------------------

@router.post(
    "/ask",
    response_model=AskResponse
)
def ask(request: AskRequest):

    try:

        result = rag.ask(

            request.question,

            request.top_k

        )

        sources = []

        for score, chunk in result["chunks"]:

            sources.append(

                Source(

                    heading=chunk["heading"],

                    lesson=chunk["lesson_title"],

                    page=chunk["page_start"],

                    score=round(score, 4)

                )

            )

        return AskResponse(

            answer=result["answer"],

            sources=sources

        )

    except Exception as e:

        raise HTTPException(

            status_code=500,

            detail=str(e)

        )