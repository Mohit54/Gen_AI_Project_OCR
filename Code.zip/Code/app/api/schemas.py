from pydantic import BaseModel, Field


class AskRequest(BaseModel):
    question: str = Field(
        ...,
        description="User question"
    )

    top_k: int = Field(
        default=5,
        ge=1,
        le=20,
        description="Number of chunks to retrieve"
    )


class Source(BaseModel):

    heading: str

    lesson: str

    page: int | None = None

    score: float


class AskResponse(BaseModel):

    answer: str

    sources: list[Source]