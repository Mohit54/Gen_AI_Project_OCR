import os

from dotenv import load_dotenv

load_dotenv()


class Config:

    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

    MONGO_URI = os.getenv(
        "MONGO_URI",
        "mongodb://localhost:27017/"
    )

    EMBEDDING_MODEL = "text-embedding-3-small"

    CHAT_MODEL = "gpt-5-mini"


config = Config()