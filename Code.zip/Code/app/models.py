from __future__ import annotations

from pydantic import BaseModel, Field


# =====================================================
# SMALL OBJECTS
# =====================================================

class Sidebar(BaseModel):
    sidebar_type: str
    title: str = ""
    content: str = ""


class Figure(BaseModel):
    image: str
    caption: str = ""
    page: int | None = None


class Table(BaseModel):
    markdown: str
    caption: str = ""


# =====================================================
# LEARNING OBJECTIVE
# =====================================================

class LearningObjective(BaseModel):

    id: str

    text: str


# =====================================================
# CONCEPT
# =====================================================

class Concept(BaseModel):

    concept_id: str

    title: str

    learning_objective: LearningObjective | None = None

    heading_path: list[str] = Field(default_factory=list)

    context: str = ""

    page_start: int | None = None

    page_end: int | None = None

    figures: list[Figure] = Field(default_factory=list)

    tables: list[Table] = Field(default_factory=list)

    sidebars: list[Sidebar] = Field(default_factory=list)


# =====================================================
# LESSON
# =====================================================

class Lesson(BaseModel):

    lesson_id: str

    title: str

    learning_objectives: list[LearningObjective] = Field(default_factory=list)

    concepts: list[Concept] = Field(default_factory=list)

    def add_learning_objective(self, lo: LearningObjective):

        self.learning_objectives.append(lo)

    def add_concept(self, concept: Concept):

        self.concepts.append(concept)


# =====================================================
# BOOK
# =====================================================

class Book(BaseModel):

    title: str

    lessons: list[Lesson] = Field(default_factory=list)

    def add_lesson(self, lesson: Lesson):

        self.lessons.append(lesson)