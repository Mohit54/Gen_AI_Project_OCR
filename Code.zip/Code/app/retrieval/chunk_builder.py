import math

from app.retrieval.models import Chunk


class ChunkBuilder:

    def __init__(

        self,

        chunk_size=400,

        overlap=50

    ):

        self.chunk_size = chunk_size

        self.overlap = overlap

    # ----------------------------------------

    def split_text(self, text):

        words = text.split()

        chunks = []

        start = 0

        while start < len(words):

            end = start + self.chunk_size

            chunk = " ".join(

                words[start:end]

            )

            chunks.append(chunk)

            start += (

                self.chunk_size

                - self.overlap

            )

        return chunks

    # ----------------------------------------

    def build(self, concepts):

        output = []

        for concept in concepts:

            chunks = self.split_text(

                concept["content"]

            )

            total = len(chunks)

            for i, chunk in enumerate(chunks):

                output.append(

                    Chunk(

                        chunk_id=f"{concept['concept_id']}_{i+1}",

                        concept_id=concept["concept_id"],

                        lesson_title=concept["lesson_title"],

                        heading=concept["heading"],

                        heading_path=concept["heading_path"],

                        learning_objective=concept["learning_objective"],

                        page_start=concept["page_start"],

                        page_end=concept["page_end"],

                        chunk_index=i + 1,

                        total_chunks=total,

                        text=chunk,

                        token_count=len(chunk.split()),

                        keywords=concept["keywords"],

                        definitions=concept["definitions"],

                        important_points=concept["important_points"],

                        figures=concept["figures"],

                        tables=concept["tables"],

                        sidebars=concept["sidebars"]

                    )

                )

        return output