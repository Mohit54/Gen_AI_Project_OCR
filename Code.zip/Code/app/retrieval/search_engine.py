import numpy as np

from pymongo import MongoClient
from openai import OpenAI


class SearchEngine:

    def __init__(self, api_key):

        self.client = OpenAI(api_key=api_key)

        self.mongo = MongoClient(
            "mongodb://localhost:27017/"
        )

        self.collection = self.mongo.CourseDB.chunks

    # ------------------------------------

    def get_embedding(self, text):

        response = self.client.embeddings.create(

            model="text-embedding-3-small",

            input=text

        )

        return response.data[0].embedding

    # ------------------------------------

    @staticmethod
    def cosine_similarity(a, b):

        a = np.array(a)

        b = np.array(b)

        return np.dot(a, b) / (
            np.linalg.norm(a)
            * np.linalg.norm(b)
        )

    # ------------------------------------

    def search(

        self,

        query,

        top_k=5

    ):

        query_embedding = self.get_embedding(query)

        results = []

        for chunk in self.collection.find():

            score = self.cosine_similarity(

                query_embedding,

                chunk["embedding"]

            )

            results.append(

                (

                    score,

                    chunk

                )

            )

        results.sort(

            key=lambda x: x[0],

            reverse=True

        )

        return results[:top_k]