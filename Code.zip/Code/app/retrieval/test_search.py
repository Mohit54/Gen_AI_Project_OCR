import json

from embedding_service import EmbeddingService

from mongo_service import MongoService

from search_service import SearchService



embedder = EmbeddingService(API_KEY)

mongo = MongoService()

mongo.clear()

# ---------------------------------------

with open(

    r"C:\Users\mohit\PycharmProjects\Gen_AI_Project\Code\output\course_concepts.json",

    encoding="utf8"

) as f:

    concepts = json.load(f)

# ---------------------------------------

print("Creating embeddings...")

for concept in concepts:

    search_text = f"""

Heading

{concept['heading']}

Lesson

{concept['lesson_title']}

Learning Objective

{concept['learning_objective']}

Keywords

{' '.join(concept['keywords'])}

Definitions

{' '.join(concept['definitions'])}

Content

{concept['content']}

"""

    embedding = embedder.generate(

        search_text

    )

    mongo.insert({

        "concept_id": concept["concept_id"],

        "lesson": concept["lesson_title"],

        "heading": concept["heading"],

        "content": concept["content"],

        "page": concept["page_start"],

        "embedding": embedding

    })

print("Mongo Ready")

search = SearchService()

while True:

    query = input("\nQuestion : ")

    if query == "exit":

        break

    query_embedding = embedder.generate(

        query

    )

    docs = mongo.get_all()

    results = search.search(

        query_embedding,

        docs,

        top_k=5

    )

    print()

    for score, doc in results:

        print("=" * 60)

        print("Score :", score)

        print("Heading :", doc["heading"])

        print("Lesson :", doc["lesson"])

        print("Page :", doc["page"])

        print()

        print(doc["content"][:400])