from openai import OpenAI


# class EmbeddingService:
#
#     def __init__(self, api_key):
#
#         self.client = OpenAI(api_key=api_key)
#
#         self.model = "text-embedding-3-small"
#
#     def generate(self, text):
#
#         response = self.client.embeddings.create(
#
#             model=self.model,
#
#             input=text
#
#         )
#
#         return response.data[0].embedding

from openai import OpenAI


class EmbeddingService:

    def __init__(self, api_key):

        self.client = OpenAI(api_key=api_key)

        self.model = "text-embedding-3-small"

    def embed(self, text: str):

        response = self.client.embeddings.create(

            model=self.model,

            input=text

        )

        return response.data[0].embedding