from pymongo import MongoClient


# class MongoService:
#
#     def __init__(self):
#
#         self.client = MongoClient(
#
#             "mongodb://localhost:27017/"
#         )
#
#         self.db = self.client["CourseDB"]
#
#         self.collection = self.db["concepts"]
#
#     def clear(self):
#
#         self.collection.drop()
#
#     def insert(self, document):
#
#         self.collection.insert_one(document)
#
#     def get_all(self):
#
#         return list(
#
#             self.collection.find()
#
#         )
from pymongo import MongoClient


class MongoService:

    def __init__(self):

        self.client = MongoClient(

            "mongodb://localhost:27017/"
        )

        self.db = self.client["CourseDB"]

        self.collection = self.db["chunks"]

    # ------------------------------

    def clear(self):

        self.collection.drop()

    # ------------------------------

    def insert(self, document):

        self.collection.insert_one(document)

    # ------------------------------

    def count(self):

        return self.collection.count_documents({})

    # ------------------------------

    def get_all(self):

        return list(

            self.collection.find()

        )