import json

from app.retrieval.embedding_service import EmbeddingService
from app.retrieval.mongo_service import MongoService


# -----------------------------------------
# CONFIG
# -----------------------------------------


INPUT_JSON = r"C:\Users\mohit\PycharmProjects\Gen_AI_Project\Code\app\retrieval\output\course_chunks.json"

# -----------------------------------------

embedder = EmbeddingService(API_KEY)

mongo = MongoService()

mongo.clear()

print("=" * 60)
print("BUILDING CHUNK EMBEDDINGS")
print("=" * 60)

# -----------------------------------------

with open(

    INPUT_JSON,

    encoding="utf8"

) as f:

    chunks = json.load(f)

print(f"\nLoaded {len(chunks)} chunks")

# -----------------------------------------

for i, chunk in enumerate(chunks, start=1):

    search_text = f"""
Heading:
{chunk['heading']}

Lesson:
{chunk['lesson_title']}

Learning Objective:
{chunk['learning_objective']}

Keywords:
{' '.join(chunk['keywords'])}

Definitions:
{' '.join(chunk['definitions'])}

Important Points:
{' '.join(chunk['important_points'])}

Content:
{chunk['text']}
"""

    embedding = embedder.embed(

        search_text

    )

    chunk["search_text"] = search_text

    chunk["embedding"] = embedding

    mongo.insert(chunk)

    print(

        f"[{i}/{len(chunks)}] "

        f"{chunk['chunk_id']}"

    )

# -----------------------------------------

print()

print("=" * 60)

print("Completed")

print("=" * 60)

print(

    "Mongo Documents :",

    mongo.count()

)