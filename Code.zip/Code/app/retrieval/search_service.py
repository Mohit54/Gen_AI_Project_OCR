import numpy as np


class SearchService:

    @staticmethod
    def cosine(a, b):

        a = np.array(a)

        b = np.array(b)

        return np.dot(a, b) / (

            np.linalg.norm(a)

            *

            np.linalg.norm(b)

        )

    def search(

        self,

        query_embedding,

        documents,

        top_k=5

    ):

        scores = []

        for doc in documents:

            score = self.cosine(

                query_embedding,

                doc["embedding"]

            )

            scores.append(

                (

                    score,

                    doc

                )

            )

        scores.sort(

            reverse=True,

            key=lambda x: x[0]

        )

        return scores[:top_k]