from app.retrieval.search_engine import SearchEngine


API_KEY = "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"



engine = SearchEngine(API_KEY)


while True:

    question = input("\nQuestion : ")

    if question.lower() == "exit":

        break

    results = engine.search(question)

    print("\n")

    print("=" * 70)

    for score, chunk in results:

        print(f"Score : {score:.4f}")

        print(f"Heading : {chunk['heading']}")

        print(f"Lesson : {chunk['lesson_title']}")

        print(f"Page : {chunk['page_start']}")

        print()

        print(chunk["text"][:400])

        print()

        print("-" * 70)