from pydantic import BaseModel, Field


class Chunk(BaseModel):

    # Unique chunk id
    chunk_id: str

    # Parent concept
    concept_id: str

    # Metadata
    lesson_title: str

    heading: str

    heading_path: list[str] = Field(default_factory=list)

    learning_objective: str = ""

    page_start: int | None = None

    page_end: int | None = None

    # Chunk information
    chunk_index: int

    total_chunks: int

    text: str

    token_count: int = 0

    # Educational metadata
    keywords: list[str] = Field(default_factory=list)

    definitions: list[str] = Field(default_factory=list)

    important_points: list[str] = Field(default_factory=list)

    figures: list = Field(default_factory=list)

    tables: list = Field(default_factory=list)

    sidebars: list = Field(default_factory=list)

    # Generated later
    embedding: list[float] = Field(default_factory=list)