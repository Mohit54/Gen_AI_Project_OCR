from app.retrieval.search_engine import SearchEngine


class Retriever:

    def __init__(self, api_key):

        self.search_engine = SearchEngine(api_key)

    # ---------------------------------------------------

    def retrieve(

        self,

        question: str,

        top_k: int = 5

    ):

        """
        Returns the most relevant chunks.
        """

        return self.search_engine.search(

            query=question,

            top_k=top_k

        )