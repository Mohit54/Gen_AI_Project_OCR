import json
from pathlib import Path

from app.retrieval.chunk_builder import ChunkBuilder


INPUT_JSON = r"C:\Users\mohit\PycharmProjects\Gen_AI_Project\Code\output\course_concepts.json"
OUTPUT_JSON = "output/course_chunks.json"


def main():

    print("=" * 60)
    print("CHUNK BUILDER")
    print("=" * 60)

    # ----------------------------------------
    # Load concepts
    # ----------------------------------------

    with open(INPUT_JSON, "r", encoding="utf-8") as f:
        concepts = json.load(f)

    print(f"Loaded {len(concepts)} concepts")

    # ----------------------------------------
    # Build chunks
    # ----------------------------------------

    builder = ChunkBuilder(
        chunk_size=350,
        overlap=50
    )

    chunks = builder.build(concepts)

    print(f"Generated {len(chunks)} chunks")

    # ----------------------------------------
    # Save
    # ----------------------------------------

    output = [
        chunk.model_dump()
        for chunk in chunks
    ]

    Path("output").mkdir(
        exist_ok=True
    )

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            output,
            f,
            indent=4,
            ensure_ascii=False
        )

    print(f"Saved -> {OUTPUT_JSON}")

    print("\nSample Chunk\n")
    print("=" * 60)

    sample = output[0]

    print("Chunk ID :", sample["chunk_id"])
    print("Heading  :", sample["heading"])
    print("Words    :", sample["token_count"])

    print("\nPreview\n")

    print(sample["text"][:500])


if __name__ == "__main__":
    main()