"""
ocr_service.py

Responsibilities
----------------
1. Upload PDF
2. Run Mistral OCR
3. Save raw markdown
4. Save OCR JSON
5. Save page metadata
6. Return OCR result for downstream processing
"""

from pathlib import Path
from mistralai.client import Mistral

# from app.config import (
#     MISTRAL_API_KEY,
#     OCR_MODEL,
# )
from config import (
    MISTRAL_API_KEY,
    OCR_MODEL,
)
class OCRService:

    def __init__(self):

        self.client = Mistral(
            api_key=MISTRAL_API_KEY
        )

    # ----------------------------------------------------------

    def upload_pdf(self, pdf_path: Path):

        return self.client.files.upload(
            file={
                "file_name": pdf_path.name,
                "content": pdf_path.read_bytes()
            },
            purpose="ocr"
        )

    # ----------------------------------------------------------

    def get_signed_url(self, file_id):

        return self.client.files.get_signed_url(
            file_id=file_id
        )

    # ----------------------------------------------------------

    def process_pdf(self, pdf_path: Path):

        uploaded = self.upload_pdf(pdf_path)

        signed = self.get_signed_url(
            uploaded.id
        )

        response = self.client.ocr.process(
            model=OCR_MODEL,
            document={
                "type":"document_url",
                "document_url":signed.url
            }
        )

        return response

    # ----------------------------------------------------------

    def response_to_markdown(self, response):

        markdown = []

        for page in response.pages:

            markdown.append(
                f"\n<!-- PAGE {page.index+1} -->\n\n"
            )

            markdown.append(
                page.markdown or ""
            )

            markdown.append("\n\n")

        return "".join(markdown)

    # ----------------------------------------------------------

    def extract_page_metadata(self, response):

        metadata = []

        for page in response.pages:

            dimensions = None

            if page.dimensions:
                dimensions = {
                    "dpi": getattr(page.dimensions, "dpi", None),
                    "height": getattr(page.dimensions, "height", None),
                    "width": getattr(page.dimensions, "width", None)
                }

            metadata.append(
                {
                    "page": page.index + 1,
                    "markdown_length": len(page.markdown or ""),
                    "images": len(page.images or []),
                    "dimensions": dimensions
                }
            )

        return metadata
    # ----------------------------------------------------------

    def save_outputs(
            self,
            response,
            output_dir:Path
    ):

        output_dir.mkdir(
            exist_ok=True,
            parents=True
        )

        md=self.response_to_markdown(
            response
        )

        (output_dir/"raw.md").write_text(
            md,
            encoding="utf8"
        )

        (output_dir/"ocr_response.json").write_text(

            response.model_dump_json(
                indent=2
            ),

            encoding="utf8"
        )

        import json

        with open(

            output_dir/"page_metadata.json",

            "w",

            encoding="utf8"

        ) as fp:

            json.dump(

                self.extract_page_metadata(
                    response
                ),

                fp,

                indent=4

            )

        return md

    # ----------------------------------------------------------

    def run(
            self,
            pdf_path,
            output_dir
    ):

        pdf_path=Path(pdf_path)

        response=self.process_pdf(
            pdf_path
        )

        markdown=self.save_outputs(
            response,
            Path(output_dir)
        )

        return response,markdown
