import re


class ImportantPointExtractor:

    HEADINGS = {

        "remember",

        "important",

        "note",

        "key point",

        "clinical pearl",

        "caution",

        "warning",

        "tip",

        "focus on",

        "did you know",

        "safety",

        "alert"
    }

    @classmethod
    def extract(cls, concept):

        important_points = []

        # ----------------------------------------
        # 1. Sidebars
        # ----------------------------------------

        for sidebar in concept.sidebars:

            title = ""

            content = ""

            if hasattr(sidebar, "title"):

                title = sidebar.title.strip()

            if hasattr(sidebar, "content"):

                content = sidebar.content.strip()

            if title.lower() in cls.HEADINGS:

                if content:

                    important_points.append(content)

        # ----------------------------------------
        # 2. Bold Keywords
        # ----------------------------------------

        markdown = concept.markdown

        bolds = re.findall(

            r"\*\*(.*?)\*\*",

            markdown

        )

        for bold in bolds:

            bold = bold.strip()

            if len(bold) > 2:

                important_points.append(bold)

        # ----------------------------------------
        # Remove duplicates
        # ----------------------------------------

        unique = []

        seen = set()

        for item in important_points:

            if item not in seen:

                unique.append(item)

                seen.add(item)

        return unique