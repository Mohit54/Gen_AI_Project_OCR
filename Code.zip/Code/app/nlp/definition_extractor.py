import re


class DefinitionExtractor:

    PATTERNS = [

        r'^\s*A\s+\*{0,2}.+?\*{0,2}\s+is\s+.+',

        r'^\s*An\s+\*{0,2}.+?\*{0,2}\s+is\s+.+',

        r'^\s*The\s+\*{0,2}.+?\*{0,2}\s+is\s+.+',

        r'.+\s+refers to\s+.+',

        r'.+\s+defined as\s+.+',

        r'.+\s+known as\s+.+',

        r'.+\s+is the study of\s+.+',

        r'.+\s+are groups? of\s+.+',

        r'.+\s+is a type of\s+.+',
    ]


    @classmethod
    def extract(cls, text: str):

        if not text:
            return []

        definitions = []

        sentences = re.split(

            r'(?<=[.!?])\s+',

            text

        )

        for sentence in sentences:

            sentence = sentence.strip()

            if len(sentence) < 20:
                continue

            # ignore questions

            if sentence.endswith("?"):
                continue

            # ignore numbered list

            if re.match(r'^\d+\.', sentence):
                continue

            # ignore bullet

            if sentence.startswith("-"):
                continue

            for pattern in cls.PATTERNS:

                if re.search(

                    pattern,

                    sentence,

                    re.IGNORECASE

                ):

                    definitions.append(sentence)

                    break

        return definitions