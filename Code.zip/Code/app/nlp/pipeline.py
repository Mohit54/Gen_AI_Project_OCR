from app.builder.keyword_builder import KeywordBuilder
from app.nlp.definition_extractor import DefinitionExtractor
from app.nlp.example_extractor import ExampleExtractor
from app.nlp.important_point_extractor import ImportantPointExtractor
class NLPPipeline:

    def run(self, concepts):

        concepts = self.extract_keywords(concepts)

        concepts = self.extract_definitions(concepts)

        concepts = self.extract_examples(concepts)

        concepts = self.extract_important_points(concepts)

        return concepts

    # ------------------------------------------------

    def extract_keywords(self, concepts):

        return KeywordBuilder().build(concepts)

    # ------------------------------------------------

    def extract_definitions(self, concepts):

        for concept in concepts:

            concept.definitions = DefinitionExtractor.extract(
                concept.content
            )

        return concepts

    def extract_examples(self, concepts):

        for concept in concepts:
            concept.examples = ExampleExtractor.extract(
                concept.content
            )

        return concepts

    def extract_important_points(self, concepts):

        for concept in concepts:
            concept.important_points = (

                ImportantPointExtractor.extract(

                    concept

                )

            )

        return concepts