import re


class ExampleExtractor:

    PATTERNS = [

        r'for example',

        r'example',

        r'such as',

        r'e\.g\.',

        r'for instance'
    ]

    @classmethod
    def extract(cls, text):

        if not text:
            return []

        examples = []

        sentences = re.split(
            r'(?<=[.!?])\s+',
            text
        )

        for sentence in sentences:

            sentence = sentence.strip()

            for pattern in cls.PATTERNS:

                if re.search(
                    pattern,
                    sentence,
                    re.IGNORECASE
                ):

                    examples.append(sentence)

                    break

        return examples