from openai import OpenAI

from app.rag.prompt_builder import PromptBuilder
from app.retrieval.retriever import Retriever


class RAGService:

    def __init__(

        self,

        api_key

    ):

        self.client = OpenAI(

            api_key=api_key

        )

        self.retriever = Retriever(

            api_key

        )

    # ---------------------------------------------------

    def ask(

        self,

        question,

        top_k=5

    ):

        chunks = self.retriever.retrieve(

            question,

            top_k

        )

        prompt = PromptBuilder.build(

            question,

            chunks

        )

        response = self.client.chat.completions.create(

            model="gpt-5-mini",

            messages=[

                {

                    "role": "system",

                    "content": "You answer educational questions using only the supplied context."

                },

                {

                    "role": "user",

                    "content": prompt

                }

            ]

        )

        answer = response.choices[0].message.content

        return {

            "answer": answer,

            "chunks": chunks

        }