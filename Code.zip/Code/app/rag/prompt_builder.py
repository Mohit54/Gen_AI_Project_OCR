class PromptBuilder:

    @staticmethod
    def build(

        question: str,

        chunks

    ) -> str:

        context = []

        for score, chunk in chunks:

            context.append(

                f"""
Heading:
{chunk['heading']}

Lesson:
{chunk['lesson_title']}

Page:
{chunk['page_start']}

Content:
{chunk['text']}
"""

            )

        context = "\n\n".join(context)

        prompt = f"""
You are an educational assistant.

Answer ONLY using the supplied context.

If the answer is not present,
reply with:

"I couldn't find the answer in the textbook."

Context:

{context}

Question:

{question}

Answer:
"""

        return prompt