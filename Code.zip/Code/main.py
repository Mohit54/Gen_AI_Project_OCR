from pathlib import Path

from app.builder import keyword_extractor
from app.ocr.ocr_service import OCRService
from app.parser.markdown_cleaner import *
from app.parser.markdown_parser import MarkdownParser
from app.models import Figure

from app.parser.hierarchy_builder import HierarchyBuilder
from app.builder.concept_builder import ConceptBuilder
from app.exporter.json_exporter import JSONExporter
from app.builder.keyword_builder import KeywordBuilder
from app.builder.keyword_extractor import KeywordExtractor
keyword_extractor=KeywordExtractor()

concept_builder = ConceptBuilder()


builder = HierarchyBuilder()
# ---------------------------------------


INPUT_PDF = "9780357436479_2.pdf"

OUTPUT_DIR = Path("output")
OUTPUT_DIR.mkdir(exist_ok=True)

ocr = OCRService()
def main():

    print("=" * 60)
    print("MISTRAL OCR PIPELINE")
    print("=" * 60)

    # -----------------------------
    # Step 1 : OCR
    # -----------------------------
    print("\n[1/2] Running OCR...")

    response, raw_markdown = ocr.run(
        INPUT_PDF,
        OUTPUT_DIR
    )

    raw_md_path = OUTPUT_DIR / "raw.md"

    raw_md_path.write_text(
        raw_markdown,
        encoding="utf-8"
    )

    print(f"Raw markdown saved -> {raw_md_path}")

    # -----------------------------
    # Step 2 : Clean markdown
    # -----------------------------
    print("\n[2/2] Cleaning markdown...")

    cleaner = MarkdownCleaner()

    cleaned = cleaner.clean(raw_markdown)

    clean_md_path = OUTPUT_DIR / "clean.md"

    clean_md_path.write_text(
        cleaned,
        encoding="utf-8"
    )

    print(f"Clean markdown saved -> {clean_md_path}")

    print("\nPipeline completed successfully.")
    from app.parser.markdown_parser import MarkdownParser

    # ---------------------------------------

    parser = MarkdownParser()

    book = parser.parse(cleaned)

    #print(parser.print_tree(book))


    book = builder.build(parser.book)

    #print(book.model_dump_json(indent=2))
    #builder.print_summary()
    course_concepts = concept_builder.build(book)

    print(f"\nCourse Concepts : {len(course_concepts)}")
    keyword_builder = KeywordBuilder()


    course_concepts = keyword_builder.build(
        course_concepts
    )


    JSONExporter.export_course_concepts(
        course_concepts,
        "output/course_concepts.json"
    )
if __name__ == "__main__":
    main()