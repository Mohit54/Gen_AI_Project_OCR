"""
Regex and constants used throughout the project.
"""

import re

# ----------------------------------------------------------
# HEADERS
# ----------------------------------------------------------

HEADER_REGEX = re.compile(
    r"^(#{1,6})\s+(.*)$"
)

# ----------------------------------------------------------
# CHAPTER
# ----------------------------------------------------------

CHAPTER_REGEX = re.compile(
    r"chapter\s+\d+",
    re.IGNORECASE
)

# ----------------------------------------------------------
# LO
# ----------------------------------------------------------

LO_REGEX = re.compile(
    r"^LO\s*\d+",
    re.IGNORECASE
)

# ----------------------------------------------------------
# FIGURES
# ----------------------------------------------------------

FIGURE_REGEX = re.compile(
    r"fig\.",
    re.IGNORECASE
)

# ----------------------------------------------------------
# TABLE
# ----------------------------------------------------------

TABLE_REGEX = re.compile(
    r"table",
    re.IGNORECASE
)

# ----------------------------------------------------------
# SIDEBAR TYPES
# ----------------------------------------------------------

SIDEBAR_TYPES = [

    "Focus On",

    "Did You Know",

    "Check In",

    "Caution",

    "Activity",

    "Procedure",

    "Safety",

    "Remember",

    "Tip",

    "Review",

    "Case Study"
]

MAX_CONCEPT_LEVEL = 2

MAX_SUBCONCEPT_LEVEL = 3

MAX_CONTENT_LEVEL = 4